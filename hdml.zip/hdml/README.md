# Portfólio — Ficheiros do site

Ficheiros incluídos:

- `index.html` — página principal (secções: Início, Sobre, Projetos, Contacto)
- `project.html` — página extra sobre um projeto (obrigatória)
- `box-model/` — site independente do exercício Box Model
- `box-model/styles.css` — CSS exclusivo do exercício Box Model
- `styles.css` — CSS externo com responsividade
- `images/placeholder.svg` — imagem de exemplo

Contacto:

- Email: `pedro_ramos@gmail.com`
- GitHub: `https://github.com/pedroscx`

Para ver localmente abra `index.html` num browser ou use um servidor local:

```bash
# Serve com Python (se disponível):
python -m http.server 8000
# depois abrir http://localhost:8000
```

Publicar com GitHub Pages:

1. Criar repositório no GitHub e adicionar remote.
2. Commit e push para a branch `main`.
3. Nas definições do repositório ativar GitHub Pages a partir da branch `main`.

Exemplo de comandos:

```bash
git init
git add .
git commit -m "Site inicial do portfólio"
git branch -M main
git remote add origin https://github.com/pedroscx/<nome-do-repo>.git
git push -u origin main
```
